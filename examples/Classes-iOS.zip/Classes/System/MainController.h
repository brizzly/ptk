

@interface MainController : UIViewController <UIAccelerometerDelegate, UIGestureRecognizerDelegate>
{
	

}



@end
