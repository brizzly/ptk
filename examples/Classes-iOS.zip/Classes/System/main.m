//
//  main.swift
//  Grizzly
//
//  Created by Julien on 05/10/2024.
//  Copyright © 2024 Jadeware Games. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainController.h"  // Import the Objective-C++ MainController class
